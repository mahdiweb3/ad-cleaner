Page Cleaner  ·  v2.0.0

نصب:
1. zip را در پوشه دائمی استخراج کن
2. chrome://extensions  →  Developer mode ON  →  Load unpacked  →  پوشه
3. یوتیوب را رفرش کن

پوشش: ~48,000 دامنه تبلیغاتی (EasyList + EasyList Adservers) روی همه سایت‌ها
+ 13,000 سلکتور CSS برای بنر/باکس تبلیغ
+ یوتیوب: حذف adPlacements/adSlots/playerAds از پاسخ پلیر

تشخیص‌نشدن: به‌جای block از redirect به stub استفاده می‌شود، پس تگ‌های
تشخیص ادبلاکر onload می‌گیرند (نه onerror) — همان چیزی که ادبلاکرها را لو می‌دهد.

محدودیت‌ها:
- دامنه‌های یوتیوب (googlevideo/ytimg/youtube/googleapis/gstatic) عمداً بلاک نمی‌شوند
  چون پخش را می‌شکند. تبلیغ یوتیوب از راه حذف payload پلیر می‌رود، نه بلاک شبکه.
- اگر یوتیوب کلیدهای payload را عوض کند، تبلیغ برمی‌گردد → main.js را آپدیت کن.
- دامنه جدید تبلیغ؟ build_rules.py را دوباره با EasyList تازه اجرا کن.

بازسازی:
  python3 build_rules.py    # EasyList -> ext/rules.json + ext/filters.css
  python3 test_v2.py        # تست واقعی در Chrome
